// wfd_capd_test.cpp : Defines the entry point for the console application.
//

#include "stdio.h"
#include "wfd_capd_v0.2.h"

int main(int argc, char* argv[])
{
	return 0;
}

