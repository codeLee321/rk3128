make ARCH=arm CROSS_COMPILE=arm-hisiv200-linux-gnueabi- KDIR=/home/hwd/hisi/hi3716/HiSTBAndroidV500R001C00SPC060/out/target/product/Hi3716CV200/obj/KERNEL_OBJ
if [ $? -eq 0 ];then
	if [ ! -e out ];then
		mkdir out
	fi
	if [ ! -e out/hi3716 ];then
		mkdir out/hi3716
	fi
mv btusb.ko out/hi3716/
fi

