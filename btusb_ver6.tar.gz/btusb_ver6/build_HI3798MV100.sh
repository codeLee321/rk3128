make ARCH=arm CROSS_COMPILE=arm-hisiv200-linux-gnueabi- KDIR=/home/hwd/hisi/hi3798/HiSTBAndroidV600R001C00SPC033/out/target/product/Hi3798MV100/obj/KERNEL_OBJ
if [ $? -eq 0 ];then
	if [ ! -e out ];then
		mkdir out
	fi
	if [ ! -e out/hi3798 ];then
		mkdir out/hi3798
	fi
mv btusb.ko out/hi3798/
fi
