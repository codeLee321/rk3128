if [ $# -lt 1 ]; then
	echo "please select"
	echo "hi3716"
	echo "hi3798"
fi
read choice
case "$choice" in
	"hi3716")
	echo "build btusb.ko for HI3716CV200"
	./build_HI3716CV200.sh
	;;
	"hi3798")
	echo "build btusb.ko for HI3798MV100"
	./build_HI3798MV100.sh
	;;
	*)
	echo "not the board"
esac
