build step:
	source ./setenv.sh
	./build.h
the "KDIR=...." in the build_HI3716CV200.sh and build_HI3798MV100.sh is need to modify according youself kernel path.   
