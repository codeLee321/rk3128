#
#!/bin/sh
#  

FIXFILES="swchangelog.commit"
ADDFILES="bfd-app-bcmdl-hisiott.sh src/usbdev/libusb-1.0.9.tar.bz2 src/usbdev/libusb-compat-0.1.3.tar.bz2"

MODFILES="src/usbdev/usbdl/Makefile commitfiles.sh"

DELFILES=""

COMMIT_REASON="logF2: To build bcmdl"

if [ "-${ADDFILES}" = "-" ]; then
echo "Do not need add any files"
else
echo "Add ${ADDFILES} to repository"
git add -f ${ADDFILES}
fi

echo "Added files: ${ADDFILES}; Modified files: ${MODFILES}; Deleted files: ${DELFILES}"
git commit -m "${COMMIT_REASON}" ${FIXFILES} ${ADDFILES} ${MODFILES} ${DELFILES}