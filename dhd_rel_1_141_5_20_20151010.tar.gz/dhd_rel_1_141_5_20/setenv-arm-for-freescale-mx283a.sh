## 
# You need to modify the exports below for your platform.
##

###################################################################
# setting the path for cross compiler
###################################################################
#export LINUXVER=2.6.37
#export KERNELDIR=/projects/hnd_video4/kernels/2.6.37-3.0/7346b0
export LINUXVER=2.6.35.3
#export LINUXVER=
#export KERNELDIR=/usr/src/linux-3.3.8
export KERNELDIR=/home/hwd/linux/zhouligong/linux-2.6.35.3
export CROSSTOOL=/opt/gcc-4.4.4-glibc-2.11.1-multilib-1.0/arm-fsl-linux-gnueabi/bin
export PATH=${CROSSTOOL}:$PATH
#export LINUXDIR=${KERNELDIR}/stblinux-${LINUXVER}
export LINUXDIR=${KERNELDIR}
#export ROOTDIR=${KERNELDIR}/uclinux-rootfs
#export EXTERNAL_OPENSSL=0
#export EXTERNAL_OPENSSL_BASE=${KERNELDIR}/openssl
#export LIBUSB_PATH=`pwd`/usbdev/install/lib
export TARGETDIR=${LINUXVER}
#export COMPAT_WIRELESS = /home/hwd/linux/patch/backports-3.14-1

###################################################################
# USBSHIM=1 if kernel is greater than or equal to 2.6.18
# USBSHIM=0 if kernel is less than 2.6.18 or using DBUS kernel object.
###################################################################
export USBSHIM=1

###################################################################
# Machine and Architecture specifics
# TARGETMACH=arm is BE
# TARGETMACH=arm_le is LE
###################################################################
export TARGETMACH=armle
export TARGETARCH=arm
export TARGETENV=linuxarm_le
#export CC=arm-linux-gnueabi-gcc
#export STRIP=arm-linux-gnueabi-strip
#export CROSS_COMPILE=arm-linux-gnueabi-
export CC=arm-fsl-linux-gnueabi-gcc
export STRIP=arm-fsl-linux-gnueabi-strip
export CROSS_COMPILE=arm-fsl-linux-gnueabi-
#add by hwd
export ARCH=arm
export PATH=$PATH:/opt/gcc-4.4.4-glibc-2.11.1-multilib-1.0/arm-fsl-linux-gnueabi/bin
###################################################################
# DO NOT MODIFY BELOW THIS LINE
###################################################################
source ./setenv.sh

