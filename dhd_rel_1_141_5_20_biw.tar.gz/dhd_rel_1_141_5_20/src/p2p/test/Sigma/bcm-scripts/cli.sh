#!/bin/bash

export WFA_ENV_CA_IPADDR=127.0.0.1
export WFA_ENV_CA_PORT=9000
echo Now enter:  ca_cli {commands}
