/*****************************************************************************
 * Wireless User Tools
 *
 * Wireless Method Types
 *****************************************************************************
*/

#if !defined(__IWLSSTYPES_H__)
#define __IWLSSTYPE_H__


enum { WLSS_WPSIE_FT_BEACON, WLSS_WPSIE_FT_PRBRSP };


#endif /* !defined(__IWLSSTYPES_H__) */
