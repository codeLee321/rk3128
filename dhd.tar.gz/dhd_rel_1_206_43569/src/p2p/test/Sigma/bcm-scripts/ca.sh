#!/bin/bash

# Run wfa_ca at the DUT PC
export WFA_ENV_AGENT_IPADDR=127.0.0.1
export WFA_ENV_AGENT_PORT=8000
./wfa_ca eth0 9000
