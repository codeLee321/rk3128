/*
 * WPS Device info
 *
 * Copyright (C) 2014, Broadcom Corporation
 * All Rights Reserved.
 * 
 * This is UNPUBLISHED PROPRIETARY SOURCE CODE of Broadcom Corporation;
 * the contents of this file may not be disclosed to third parties, copied
 * or duplicated in any form, in whole or in part, without the prior
 * written permission of Broadcom Corporation.
 *
 * $Id: info.h 296937 2011-11-17 06:35:35Z $
 */

#ifndef _INFO_
#define _INFO_

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __linux__
#include <stdio.h>
#endif

#ifdef __cplusplus
}
#endif


#endif /*  _INFO_ */
