#! /bin/sh 

 ./wpa_supplicant -Dnl80211 -c  p2p.conf -i p2p0 -dt




