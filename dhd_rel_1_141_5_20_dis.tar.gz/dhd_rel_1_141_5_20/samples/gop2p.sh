#! /bin/sh 

export LD_LIBRARY_PATH=.
./wpa_supplicant -Dnl80211 -c  p2p.conf -i p2p0 -t




