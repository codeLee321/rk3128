#! /bin/sh 

 ./wpa_cli -i eth2 -p/var/run/wpa_supplicant

