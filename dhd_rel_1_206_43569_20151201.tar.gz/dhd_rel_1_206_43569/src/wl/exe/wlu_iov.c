/*
 * Automatically generated IOVariable merge information
 * $Copyright: (c) 2006, Broadcom Corp.
 * All Rights Reserved.$
 * $Id: wlu_iov.c 461540 2014-03-12 14:31:35Z $
 *
 * Contains user IO variable information
 * Note that variable type information comes from the driver
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>

#include <typedefs.h>
#include <bcmutils.h>
#include <wlioctl.h>

#include "wlu.h"
