
# must be root to run this script

cp -pf wfascripts/* /usr/local/sbin
