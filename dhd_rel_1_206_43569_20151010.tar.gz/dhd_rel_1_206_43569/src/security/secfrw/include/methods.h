/*
 * cfg_methods.h
 * Platform independent methods functions: setup security stacks
 *
 * Copyright (C) 2014, Broadcom Corporation
 * All Rights Reserved.
 * 
 * This is UNPUBLISHED PROPRIETARY SOURCE CODE of Broadcom Corporation;
 * the contents of this file may not be disclosed to third parties, copied
 * or duplicated in any form, in whole or in part, without the prior
 * written permission of Broadcom Corporation.
 *
 * $Id: methods.h,v 1.1.1.1 2010-02-04 00:44:37 $
*/

#ifndef _CFG_METHODS_H_
#define _CFG_METHODS_H_


#endif /* _CFG_METHODS_H_ */
