#!/bin/bash

# Run wfa_dut at the DUT PC
./wfa_dut lo 8000 
